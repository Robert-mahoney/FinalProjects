
/**
 * Write a description of class GeneralGrievous here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GeneralGrievous extends Characters
{
    public GeneralGrievous()
    {
        // initialise instance variables
        super("General Grievous" , "droid, human like, dark side, separatist, green, yellow, pilot, banders fav, got butt whooped, lost a limb");
    }
}
