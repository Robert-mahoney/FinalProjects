
/**
 * Write a description of class Qira here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Qira extends Characters
{
    public Qira()
    {
        // initialise instance variables
        super("Qira" , "human like, smuggler, kessel speed, pilot");
    }
}
