
/**
 * Write a description of class Droideka here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Droideka extends Characters
{
    public Droideka()
    {
        // initialise instance variables
        super("Droideka" , "droid, dark side, separatist, banders fav");
    }
}
