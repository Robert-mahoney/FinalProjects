
/**
 * Write a description of class R2D2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class R2D2 extends Characters
{
    public R2D2()
    {
        // initialise instance variables
        super("R2-D2" , "droid, light side, rebel, resistance, galactic republic, pilot, cute");
    }
}
