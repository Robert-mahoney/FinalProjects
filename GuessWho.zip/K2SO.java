
/**
 * Write a description of class K2SO here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class K2SO extends Characters
{
    public K2SO()
    {
        // initialise instance variables
        super("K2SO" , " droid, light side, rebel, pilot");
    }
}
