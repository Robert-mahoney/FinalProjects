
/**
 * Write a description of class ChirrutImwe here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ChirrutImwe extends Characters
{
    public ChirrutImwe()
    {
        // initialise instance variables
        super("Chirrut Imwe" , "human like, light side, rebel, still living");
    }
}
