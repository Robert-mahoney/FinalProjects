
/**
 * Write a description of class IG11 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class IG11 extends Characters
{
    public IG11()
    {
        // initialise instance variables
        super("IG-11" , "droid, bounty hunter");
    }
}
