
/**
 * Write a description of class DarthVader here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DarthVader extends Characters
{
    public DarthVader()
    {
        // initialise instance variables
        super("Darth Vader" , "droid, human like, dark side, empire, red, tall, pilot, banders fav, got butt whooped, space balls");
    }
}
