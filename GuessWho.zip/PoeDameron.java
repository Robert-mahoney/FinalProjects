
/**
 * Write a description of class PoeDameron here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PoeDameron extends Characters
{
    public PoeDameron()
    {
        // initialise instance variables
        super("Poe Dameron" , "human like, light side, resistance, pilot");
    }
}
