
/**
 * Write a description of class AdmiralPiett here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AdmiralPiett extends Characters
{
    public AdmiralPiett()
    {
        // initialise instance variables
        super("Admiral Piett" , "human like, dark side, empire, galactic republic, pilot, space balls character");
    }
}
