
/**
 * Write a description of class PrincessLeia here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PrincessLeia extends Characters
{
    public PrincessLeia()
    {
        // initialise instance variables
        super("Princess Leia" , "human like, light side, rebel resistance, pilot, annoying, living, space balls");
    }
}
