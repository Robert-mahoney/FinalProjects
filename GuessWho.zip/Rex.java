
/**
 * Write a description of class Rex here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Rex extends Characters
{
    public Rex()
    {
        // initialise instance variables
        super("Rex" , "human like, light side, rebel, galactic republic, pilot");
    }
}
