
/**
 * Write a description of class WedgeAntilles here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class WedgeAntilles extends Characters
{
    public WedgeAntilles()
    {
        // initialise instance variables
        super("Wedge Antilles" , "human like, light side, rebel, pilot");
    }
}
