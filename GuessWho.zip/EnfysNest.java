
/**
 * Write a description of class EnfysNest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EnfysNest extends Characters
{
    public EnfysNest()
    {
        // initialise instance variables
        super("Enfys Nest" , "human like, light side");
    }
}
