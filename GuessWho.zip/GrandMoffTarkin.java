
/**
 * Write a description of class GrandMoffTarkin here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GrandMoffTarkin extends Characters
{
    public GrandMoffTarkin()
    {
        // initialise instance variables
        super("Grand Moff Tarkin" , "human like, dark side, empire, galactic republic, pilot");
    }
}
