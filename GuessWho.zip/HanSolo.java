
/**
 * Write a description of class HanSolo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class HanSolo extends Characters
{
    public HanSolo()
    {
        // initialise instance variables
        super("Han Solo" , "human like, light side, smuggler, kessel speed, rebel, resistance, pilot, inside a tauntaun, space balls");
    }
}
