
/**
 * Write a description of class ObiWanKenobi here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ObiWanKenobi extends Characters
{
    public ObiWanKenobi()
    {
        // initialise instance variables
        super("Obi-Wan Kenobi" , "jedi, human like, light side, galactic republic, blue, pilot, got butt whooped, living");
    }
}
