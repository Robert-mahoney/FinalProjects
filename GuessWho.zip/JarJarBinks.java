
/**
 * Write a description of class JarJarBinks here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class JarJarBinks extends Characters
{
    public JarJarBinks()
    {
        // initialise instance variables
        super("Jar Jar Binks" , "dark side, light side, empire, first order, separtist, galactic republic, annoying, cute, living");
    }
}
