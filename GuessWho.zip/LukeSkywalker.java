
/**
 * Write a description of class LukeSkywalker here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LukeSkywalker extends Characters
{
    public LukeSkywalker()
    {
        // initialise instance variables
        super("Luke Skywalker" , "jedi, human like, light side, rebel, resistance, green, got butt whooped, tauntaun, living, lost a limb");
    }
}
