
/**
 * Write a description of class EzraBridger here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EzraBridger extends Characters
{
    public EzraBridger()
    {
        // initialise instance variables
        super("Ezra Bridger" , "jedi, human like, light side, rebel, green, tall, pilot, annoying");
    }
}
