
/**
 * Write a description of class Finn here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Finn extends Characters
{
    public Finn()
    {
        // initialise instance variables
        super("Finn" , "jedi, human like, light side, resistance, pilot, annoying, living");
    }
}
