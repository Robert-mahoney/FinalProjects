
/**
 * Write a description of class QuiGonJinn here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class QuiGonJinn extends Characters
{
    public QuiGonJinn()
    {
        // initialise instance variables
        super("Qui-Gon Jinn" , "jedi, human like, dark side, light side, green, pilot, banders fav, got butt whooped");
    }
}
