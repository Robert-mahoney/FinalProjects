
/**
 * Write a description of class AhsokaTano here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AhsokaTano extends Characters
{
    public AhsokaTano()
    {
        // initialise instance variables
        super("Ahsoka Tano" , "jedi, lights side, galactic republic, white, short, pilot, still living");
    }
}
