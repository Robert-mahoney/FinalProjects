
/**
 * Write a description of class CountDooku here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CountDooku extends Characters
{
    public CountDooku()
    {
        // initialise instance variables
        super("Count Dooku" , "jedi, human like, dark side, separatist, red, pilot, got butt whooped");
    }
}
