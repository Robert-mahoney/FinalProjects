
/**
 * Write a description of class Greedo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Greedo extends Characters
{
    public Greedo()
    {
        // initialise instance variables
        super("Greedo" , "bounty hunter, got butt whooped");
    }
}
