
/**
 * Write a description of class Bossk here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Bossk extends Characters
{
    public Bossk()
    {
        // initialise instance variables
        super("Bossk" , "bounty hunter, pilot");
    }
}
