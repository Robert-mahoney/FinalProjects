
/**
 * Write a description of class PloKoon here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PloKoon extends Characters
{
    public PloKoon()
    {
        // initialise instance variables
        super("Plo Koon" , "jedi, light side, galactic republic, blue, pilot");
    }
}
