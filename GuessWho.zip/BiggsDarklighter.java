
/**
 * Write a description of class BiggsDarklighter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BiggsDarklighter extends Characters
{
    public BiggsDarklighter()
    {
        // initialise instance variables
        super("Biggs Darklighter" , "human like, light side, rebel, pilot");
    }
}
