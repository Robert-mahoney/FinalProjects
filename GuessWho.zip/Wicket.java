
/**
 * Write a description of class Wicket here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Wicket extends Characters
{
    public Wicket()
    {
        // initialise instance variables
        super("Wicket" , "light side, rebel, ewok, fluffy, short, banders fav");
    }
}
