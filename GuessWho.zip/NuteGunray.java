
/**
 * Write a description of class NuteGunray here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NuteGunray extends Characters
{
    public NuteGunray()
    {
        // initialise instance variables
        super("Nute Gunray" , "dark side, separatist, slimey, annoying");
    }
}
