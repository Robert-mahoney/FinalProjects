
/**
 * Write a description of class DarthMaul here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DarthMaul extends Characters
{
    public DarthMaul()
    {
        // initialise instance variables
        super("Darth Maul" , "human like, dark side, separatist, red, pilot, banders fav");
    }
}
