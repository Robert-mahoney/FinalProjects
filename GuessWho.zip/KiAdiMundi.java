
/**
 * Write a description of class KiAdiMundi here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class KiAdiMundi extends Characters
{
    public KiAdiMundi()
    {
        // initialise instance variables
        super("Ki-Adi-Mundi" , "jedi, light side, galactic republic, fluffy, blue");
    }
}
