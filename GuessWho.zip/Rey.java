
/**
 * Write a description of class Rey here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Rey extends Characters
{
    public Rey()
    {
        // initialise instance variables
        super("Rey" , "jedi, human like, light side, dark side, resistance, yellow, pilot, annoying, banders fav, got butt whooped, living");
    }
}
