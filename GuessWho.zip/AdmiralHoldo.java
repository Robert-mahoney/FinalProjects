
/**
 * Write a description of class AdmiralHoldo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AdmiralHoldo extends Characters
{
    public AdmiralHoldo()
    {
        // initialise instance variables
        super("Admiral Holdo" , "human like, light side, resistance, tall, pilot, annoying");
    }
}
