
/**
 * Write a description of class AnakinSkywalker here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AnakinSkywalker extends Characters
{
    public AnakinSkywalker()
    {
        // initialise instance variables
        super("Anakin Skywalker" , "jedi, human like, light side, galactic republic, slimey, blue, pilot, annoying, got butt whooped, living, lost a limb");
    }
}
