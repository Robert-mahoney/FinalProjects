
/**
 * Write a description of class KyloRen here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class KyloRen extends Characters
{
    public KyloRen()
    {
        // initialise instance variables
        super("Kylo Ren" , "jedi, dark side, light side, first order, blue, got butt whooped");
    }
}
