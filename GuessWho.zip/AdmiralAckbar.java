
/**
 * Write a description of class AdmiralAckbar here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AdmiralAckbar extends Characters
{
    public AdmiralAckbar()
    {
        // initialise instance variables
        super("Admiral Ackbar" , "light side, rebel, galactic republic, slimey, pilot");
    }
}
