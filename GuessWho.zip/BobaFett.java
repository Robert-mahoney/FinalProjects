
/**
 * Write a description of class BobaFett here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BobaFett extends Characters
{
    public BobaFett()
    {
        // initialise instance variables
        super("Boba Fett" , "human like, bounty hunter, pilot, banders fav, still living");
    }
}
