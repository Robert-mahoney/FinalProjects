
/**
 * Write a description of class PadmeAmidala here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PadmeAmidala extends Characters
{
    public PadmeAmidala()
    {
        // initialise instance variables
        super("Padme Amidala" , "human like, light side, galactic republic, pilot, annoying, got butt whooped");
    }
}
