
/**
 * Write a description of class MaceWindu here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MaceWindu extends Characters
{
    public MaceWindu()
    {
        // initialise instance variables
        super("Mace Windu" , "jedi, human like, light side, galactic rebublic, purple, banders fav, got butt whooped, living, lost a limb");
    }
}
