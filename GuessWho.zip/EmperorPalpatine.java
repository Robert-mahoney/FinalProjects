
/**
 * Write a description of class EmperorPalpatine here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EmperorPalpatine extends Characters
{
    public EmperorPalpatine()
    {
        // initialise instance variables
        super("Emperor Palpatine" , "droid, human like, dark side, light side, empire, separatist, galactic republic, red, banders fav, still living, space balls");
    }
}
