
/**
 * Write a description of class C3PO here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class C3PO extends Characters
{
    public C3PO()
    {
        // initialise instance variables
        super("C-3PO" , "droid, light side, rebel, resistance, galactic republic,slimey, got butt whooped ,still living ,lost a limb ,space balls character ");
    }
}
