
/**
 * Write a description of class BB8 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BB8 extends Characters
{
    public BB8()
    {
        // initialise instance variables
        super("BB-8" , "droid, light side, resistance, short, pilot, cute");
    }
}
