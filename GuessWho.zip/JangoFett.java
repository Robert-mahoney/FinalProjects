
/**
 * Write a description of class JangoFett here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class JangoFett extends Characters
{
    public JangoFett()
    {
        // initialise instance variables
        super("Jango Fett" , "human like, bounty hunter, separatist, pilot, banders fav, lost a limb");
    }
}
