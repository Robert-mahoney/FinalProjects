
/**
 * Write a description of class JabbatheHut here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class JabbatheHut extends Characters
{
    public JabbatheHut()
    {
        // initialise instance variables
        super("Jabba the Hut" , "bounty hunter, slimy, short, cute, got butt whooped, space balls");
    }
}
