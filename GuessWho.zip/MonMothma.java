
/**
 * Write a description of class MonMothma here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MonMothma extends Characters
{
    public MonMothma()
    {
        // initialise instance variables
        super("Mon Mothma" , "human like, light side, rebel, resistance");
    }
}
