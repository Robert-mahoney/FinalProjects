
/**
 * Write a description of class Yoda here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Yoda extends Characters
{
    public Yoda()
    {
        // initialise instance variables
        super("Yoda" , "jedi, light side, rebel, slimey, green, short, banders fav, got butt whooped, living, space ball");
    }
}
