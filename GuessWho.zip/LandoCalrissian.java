
/**
 * Write a description of class LandoCalrissian here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LandoCalrissian extends Characters
{
    public LandoCalrissian()
    {
        // initialise instance variables
        super("Lando Calrissian" , "human like, light side, smuggler, kessel speed, pilot");
    }
}
