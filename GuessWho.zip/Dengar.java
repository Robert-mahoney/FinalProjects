
/**
 * Write a description of class Dengar here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Dengar extends Characters
{
    public Dengar()
    {
        // initialise instance variables
        super("Dengar" , "human like, bounty hunter");
    }
}
