
/**
 * Write a description of class Chewbacca here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Chewbacca extends Characters
{
    public Chewbacca()
    {
        // initialise instance variables
        super("Chewbacca" , "wookie, light side, smuggler, kessel speed, rebel, resistance, galactic republic, fluffy, tall, pilot, banders fav, still living, space balls");
    }
}
