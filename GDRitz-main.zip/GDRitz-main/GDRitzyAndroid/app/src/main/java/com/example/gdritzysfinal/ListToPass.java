package com.example.gdritzysfinal;

public interface ListToPass {
    String ORDER_ITEMS = "com.example.gdritzysfinal";
    String ORDER_ITEMSCOST = "com.example.gdritzysfinal";
    String ORDER_ITEMSCUSTOM = "com.example.gdritzysfinal";
}
